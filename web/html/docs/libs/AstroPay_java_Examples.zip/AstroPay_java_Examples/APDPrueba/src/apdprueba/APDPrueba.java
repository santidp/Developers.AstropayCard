package apdprueba;

public class APDPrueba {

    public static void main(String[] args) throws Exception {
        AstroPayDirect astro = new AstroPayDirect();
            astro.construct();
            String respuesta = astro.create("Invoice de prueba AstroPay", (float)1.95, "idMeli", "", "BR", "USD", "descrp de prueba", "00003456789", 1, "", "", "string");
            System.out.println(respuesta);
            String status = astro.confirmation("9", "Invoice de prueba AstroPay", "idUser", "descr. de prueba", "1234", "1", "00", "", (float)1.95, "");
    }
    
}
