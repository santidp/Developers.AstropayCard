package carddataprueba;

public class CardDataPrueba {

    public static void main(String[] args) throws Exception {
        CardData astro = new CardData();
        astro.construct();
        String respuesta = astro.create("Invoice de prueba", (float) 1.05, "iduser", "USD", "uniqueid", "http://astropaycard.com/", "http://astropaycard.com/", "EN", "string");
        System.out.println(respuesta);
    }

}
