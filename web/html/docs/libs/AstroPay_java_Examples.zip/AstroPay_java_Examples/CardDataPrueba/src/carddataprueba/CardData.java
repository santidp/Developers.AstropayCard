package carddataprueba;

import com.sun.org.apache.xalan.internal.xsltc.runtime.Hashtable;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Enumeration;

/**
    * Example of using the class:
    * See Program.cs
    *
    * Available functions:
    * - create
    * - 
    */

    /**
     * Class of AstroPay Direct
     * 
     * @author Melissa Caraballo (melissa@astropaycard.com)
     * @version 1.0 
     *
     */

public class CardData {
    /**************************
        * Merchant configuration *
        **************************/
        private String login = "1955f2d";
        private String trans_key = "6810h5";

        private String secret_key = "4lph0ns3";

        private boolean sandbox = true;
        /*********************************
         * End of Merchant configuration *
         *********************************/

        /*****************************************************
         * ---- PLEASE DON'T CHANGE ANYTHING BELOW HERE ---- *
         *****************************************************/
        String post_url;

        final String formatter = "{0,10}{1,16}";

        public void construct()
        {
            post_url = "https://www.astropaycard.com/api_curl/transaction/";
            if (this.sandbox)
            {
                post_url = "http://sandbox.astropaycard.com/api_curl/transaction/";
            }
        }
        
        public String create(String invoice, float amount, String iduser, String currency, String unique_id, String url_return, String url_cancel, String language, String type) throws Exception
        {
            Hashtable post_values = new Hashtable();

            //Mandatory
            post_values.put("login", this.login);
            post_values.put("pass", this.trans_key);
            post_values.put("invoice", invoice);
            post_values.put("amount", amount+"");
            post_values.put("unique_id", unique_id);
            String message_to_control = invoice + "C" + amount + "P" + invoice + "A";
            String control = getSign(this.secret_key, message_to_control);
            post_values.put("control", control);
            //Optional
            post_values.put("currency", currency);
            post_values.put("url_return", url_return);
            post_values.put("url_cancel", url_cancel);
            post_values.put("language", language);
            post_values.put("type", type);

            control = control.toUpperCase();

            String response = this.curl(this.post_url + "create.php", post_values);
            return response;
        }
        
        /**
     * END OF PUBLIC INTERFACE
     */
    private String curl(String url, Hashtable post_values) throws Exception {
        String post_string = "";
        String post_response = "";
        HttpURLConnection objRequest = null;
        
        Enumeration<String> enumKey = post_values.keys();
        while(enumKey.hasMoreElements()) {
            String key = enumKey.nextElement();
            String val = post_values.get(key)+"";
            post_string += key + "=" + val + "&";
            }
        post_string = post_string.substring(0, post_string.length()-1);
        try {
            // create an HttpURLConnection object to communicate with AstroPay transaction server
            objRequest = (HttpURLConnection) new URL(url).openConnection();
            objRequest.disconnect();
            objRequest.setRequestMethod("POST");
            objRequest.setDoOutput(true);
            // post data is sent as a stream
            objRequest.getOutputStream().write(post_string.getBytes("UTF-8"));
            objRequest.connect();
            /*
            objRequest.ContentLength = post_string.Length;
            objRequest.ContentType = "application/x-www-form-urlencoded, charset=utf-8";
            */

            
            // returned values are returned as a stream, then read into a string
            BufferedReader in = new BufferedReader(new InputStreamReader(objRequest.getInputStream(), "UTF-8"));
            InputStream ggh = objRequest.getInputStream();
            post_response = in.readLine();

            // the response string is broken into an array
            // The split character specified here must match the delimiting character specified above
        } catch (Exception e) {
            throw new Exception("Error ocurred in request");
        }
        objRequest.disconnect();
        return post_response;
    }

    public static String getSign(String key, String message) throws Exception{
        javax.crypto.Mac mac = javax.crypto.Mac.getInstance("HmacSHA256");
        byte[] keyBytes = key.getBytes("UTF-8");
        byte[] messageBytes = message.getBytes("UTF-8");
        mac.init(new javax.crypto.spec.SecretKeySpec(keyBytes, mac.getAlgorithm()));
        return byteArray2HexString(mac.doFinal(messageBytes));
    }
    
    public static String byteArray2HexString(byte[] b){
        java.math.BigInteger bi = new java.math.BigInteger(1, b);
        return String.format("%0" + (b.length << 1) + "X", bi);
    }
}
