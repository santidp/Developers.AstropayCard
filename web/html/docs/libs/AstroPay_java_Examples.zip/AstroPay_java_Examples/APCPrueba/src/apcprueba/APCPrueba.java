package apcprueba;

public class APCPrueba {

    public static void main(String[] args) throws Exception {
        AstroPayCard astro = new AstroPayCard();
        astro.construct();        
        String response = astro.validator("1175000000000100", 1234, "05/2015", (float)0.6, "id user", "InvoicePrueba1102");
        //Must validate response
        String[] responseArray = response.split("\\|");
        System.out.println(response);
        boolean validateMd5 = astro.md5Validator(responseArray[39], responseArray[6], "0.6");
        System.out.println(validateMd5);
        String responseStatus = astro.transtatus("InvoicePrueba1102");
        System.out.println(responseStatus);
    }

}
