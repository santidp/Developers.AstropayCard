package apcprueba;

import com.sun.org.apache.xalan.internal.xsltc.runtime.Hashtable;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Enumeration;

/**
 * Example of using the class: See Program.cs
 *
 * Available functions: - create - transtatus
 */
/**
 * Class of AstroPay Direct
 *
 * @author Melissa Caraballo (melissa@astropaycard.com)
 * @version 1.0
 *
 */
public class AstroPayCard {

    /**
     * ************************
     * Merchant configuration * ************************
     */
    private String x_login = "1955f2d";
    private String x_trans_key = "6810h5";
    private float x_version = (float) 2.0;
    private String x_type = "AUTH_CAPTURE";
    private char x_test_request = 'N';
    private int x_duplicate_window = 60;
    private char x_delim_char = '|'; //@
    private String x_response_format = "string"; //json
    private boolean x_delim_data = true;
    private String x_method = "CC"; //json
    private String x_trans_id = "";
    private String x_auth_code = "CC"; //json

    private String x_secret_key = "4lph0ns3";

    private boolean sandbox = true;
    /**
     * *******************************
     * End of Merchant configuration * *******************************
     */

    /**
     * ***************************************************
     * ---- PLEASE DON'T CHANGE ANYTHING BELOW HERE ---- *
     * ***************************************************
     */
    String post_url;

    final String formatter = "{0,10}{1,16}";

    public void construct() {
        post_url = "https://api.astropaycard.com/verif/";
        if (this.sandbox) {
            post_url = "http://sandbox-api.astropaycard.com/verif/";
        }
    }

    public String validator(String card, int code, String expDate, float amount, String uniqueId, String invoice) throws Exception {
        Hashtable post_values = new Hashtable();

        post_values.put("x_login", this.x_login);
        post_values.put("x_tran_key", this.x_trans_key);
        post_values.put("x_version", this.x_version);
        post_values.put("x_type", this.x_type);
        post_values.put("x_test_request", this.x_test_request + "");
        post_values.put("x_card_num", card);
        post_values.put("x_card_code", code + "");
        post_values.put("x_exp_date", expDate);
        post_values.put("x_amount", amount + "");
        post_values.put("x_unique_id", uniqueId);
        post_values.put("x_invoice_num", invoice);
        post_values.put("x_duplicate_window", this.x_duplicate_window + "");
        post_values.put("x_delim_char", this.x_delim_char + "");
        post_values.put("x_response_format", this.x_response_format);
        post_values.put("x_delim_data", this.x_delim_data);
        post_values.put("x_method", this.x_method);
        post_values.put("x_trans_id", this.x_trans_id);
        post_values.put("x_auth_code", this.x_auth_code);

        String response = this.curl(this.post_url + "validator", post_values);
        return response;
    }

    public String transtatus(String invoice) throws Exception {
        Hashtable post_values = new Hashtable();

        post_values.put("x_login", this.x_login);
        post_values.put("x_trans_key", this.x_trans_key);
        post_values.put("x_invoice_num", invoice);
        post_values.put("x_test_request", this.x_test_request + "");
        post_values.put("x_type", this.x_type);
        post_values.put("x_delim_char", this.x_delim_char + "");

        String response = this.curl(this.post_url + "transtatus", post_values);
        return response;
    }

    /**
     * END OF PUBLIC INTERFACE
     */
    private String curl(String url, Hashtable post_values) throws Exception {
        String post_string = "";
        String post_response = "";
        HttpURLConnection objRequest = null;

        Enumeration<String> enumKey = post_values.keys();
        while (enumKey.hasMoreElements()) {
            String key = enumKey.nextElement();
            String val = post_values.get(key) + "";
            post_string += key + "=" + val + "&";
        }
        post_string = post_string.substring(0, post_string.length() - 1);
        try {
            // create an HttpURLConnection object to communicate with AstroPay transaction server
            objRequest = (HttpURLConnection) new URL(url).openConnection();
            objRequest.disconnect();
            objRequest.setRequestMethod("POST");
            objRequest.setDoOutput(true);
            // post data is sent as a stream
            objRequest.getOutputStream().write(post_string.getBytes("UTF-8"));
            objRequest.connect();
            /*
             objRequest.ContentLength = post_string.Length;
             objRequest.ContentType = "application/x-www-form-urlencoded, charset=utf-8";
             */

            // returned values are returned as a stream, then read into a string
            BufferedReader in = new BufferedReader(new InputStreamReader(objRequest.getInputStream(), "UTF-8"));
            InputStream ggh = objRequest.getInputStream();
            post_response = in.readLine();

            // the response string is broken into an array
            // The split character specified here must match the delimiting character specified above
        } catch (Exception e) {
            throw new Exception("Error ocurred in request");
        }
        objRequest.disconnect();
        return post_response;
    }

    public static String getSign(String key, String message) throws Exception {
        javax.crypto.Mac mac = javax.crypto.Mac.getInstance("HmacSHA256");
        byte[] keyBytes = key.getBytes("UTF-8");
        byte[] messageBytes = message.getBytes("UTF-8");
        mac.init(new javax.crypto.spec.SecretKeySpec(keyBytes, mac.getAlgorithm()));
        return byteArray2HexString(mac.doFinal(messageBytes));
    }

    public static String byteArray2HexString(byte[] b) {
        java.math.BigInteger bi = new java.math.BigInteger(1, b);
        return String.format("%0" + (b.length << 1) + "X", bi);
    }

    public boolean md5Validator(String md5Hash, String transactionId, String amount) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        String input = this.x_login + transactionId + amount;
        String nuevoMd5 = md5(input);
        return nuevoMd5.equalsIgnoreCase(md5Hash);
    }
    
    static String md5(String input)
        {
            try
            {
                MessageDigest md = MessageDigest.getInstance("MD5");
                byte[] messageDigest = md.digest(input.getBytes());
                BigInteger number = new BigInteger(1,messageDigest);
                return number.toString(16);
            }
            catch(NoSuchAlgorithmException e)
            {
                throw new RuntimeException(e);
            }
        }
}
