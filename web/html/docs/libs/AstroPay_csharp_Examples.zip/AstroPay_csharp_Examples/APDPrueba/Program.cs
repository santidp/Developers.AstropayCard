﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APDPrueba
{
    class Program
    {
        static void Main(string[] args)
        {
            AstroPayDirect astro = new AstroPayDirect();
            astro.construct();
            string respuesta = astro.create("Invoice de prueba AstroPay", (decimal)1.95, "idMeli", "", "BR", "USD", "descrp de prueba", "00003456789", 1, "", "", "string");
            Console.WriteLine(respuesta);
            string status = astro.confirmation("9", "Invoice de prueba AstroPay", "idUser", "descr. de prueba", "1234", "1", "00", "", (decimal)1.95, "");
        }
    }
}
