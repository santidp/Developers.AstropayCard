﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APCardDataPrueba
{
    class Program
    {
        static void Main(string[] args)
        {
            CardData astro = new CardData();
            astro.construct();
            string respuesta = astro.create("Invoice de prueba", (decimal)1.05, "iduser", "USD", "uniqueid", "http://astropaycard.com/", "http://astropaycard.com/", "EN", "string");
            Console.WriteLine(respuesta);
        }
    }
}
