﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace APCardDataPrueba
{
    /**
    * Example of using the class:
    * See Program.cs
    *
    * Available functions:
    * - create
    * - 
    */

    /**
     * Class of AstroPay Direct
     * 
     * @author Melissa Caraballo (melissa@astropaycard.com)
     * @version 1.0 
     *
     */

    public class AstroPayCardData
    {
        /**************************
        * Merchant configuration *
        **************************/
        private string login = "1955f2d";
        private string trans_key = "6810h5";

        private string secret_key = "4lph0ns3";

        private bool sandbox = true;
        /*********************************
         * End of Merchant configuration *
         *********************************/

        /*****************************************************
         * ---- PLEASE DON'T CHANGE ANYTHING BELOW HERE ---- *
         *****************************************************/
        string post_url;

        const string formatter = "{0,10}{1,16}";

        public void construct()
        {
            post_url = "https://wwww.astropaycard.com/api_curl/transaction/";
            if (this.sandbox)
            {
                post_url = "http://sandbox.astropaycard.com/api_curl/transaction/";
            }
        }

        public string create(string invoice, decimal amount, string iduser, string currency, string unique_id, string url_return, string url_cancel, string language, string type)
        {
            Hashtable post_values = new Hashtable();

            //Mandatory
            post_values.Add("login", this.login);
            post_values.Add("pass", this.trans_key);
            post_values.Add("invoice", invoice);
            post_values.Add("amount", amount + "");
            post_values.Add("unique_id", unique_id);
            string message_to_control = String.Concat(invoice, "C", amount, "P", invoice, "A");
            string control = getSign(this.secret_key, message_to_control);
            post_values.Add("control", control);
            //Optional
            post_values.Add("currency", currency);
            post_values.Add("url_return", url_return);
            post_values.Add("url_cancel", url_cancel);
            post_values.Add("language", language);
            post_values.Add("type", type);

            control = control.ToUpper();

            string response = this.curl(this.post_url + "create.php", post_values);
            return response;
        }

        /**
         * END OF PUBLIC INTERFACE
        */

        private string curl(string url, Hashtable post_values)
        {
            String post_string = "";
            String post_response = "";
            HttpWebRequest objRequest;
            foreach (DictionaryEntry field in post_values)
            {
                post_string += field.Key + "=" + field.Value + "&";
            }
            post_string = post_string.TrimEnd('&');

            try
            {
                // create an HttpWebRequest object to communicate with AstroPay transaction server
                objRequest = (HttpWebRequest)WebRequest.Create(url);
                objRequest.Method = "POST";
                objRequest.ContentLength = post_string.Length;
                objRequest.ContentType = "application/x-www-form-urlencoded, charset=utf-8";

                // post data is sent as a stream
                StreamWriter myWriter = null;
                myWriter = new StreamWriter(objRequest.GetRequestStream());
                myWriter.Write(post_string);
                myWriter.Close();

                // returned values are returned as a stream, then read into a string
                HttpWebResponse objResponse = (HttpWebResponse)objRequest.GetResponse();
                using (StreamReader responseStream = new StreamReader(objResponse.GetResponseStream()))
                {
                    post_response = responseStream.ReadToEnd();
                    responseStream.Close();
                }

                // the response string is broken into an array
                // The split character specified here must match the delimiting character specified above
            }
            catch (Exception e)
            {
                throw new Exception("Error ocurred in HttpWebRequest");
            }
            return post_response;
        }

        public string getSign(string key, string message)
        {
            System.Security.Cryptography.HMAC hmac = System.Security.Cryptography.HMAC.Create("HMACSHA256");
            hmac.Key = System.Text.Encoding.UTF8.GetBytes(key);
            byte[] hash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(message));
            return BitConverter.ToString(hash).Replace("-", "").ToUpperInvariant();
        }
    }
}
