﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace APCPrueba
{
    /**
    * Example of using the class:
    * See Program.cs
    *
    * Available functions:
    * - create
    * - transtatus
    */

    /**
     * Class of AstroPay Direct
     * 
     * @author Melissa Caraballo (melissa@astropaycard.com)
     * @version 1.0 
     *
     */
    public class AstroPayCard
    {
        /**************************
        * Merchant configuration *
        **************************/
        private string x_login = "1955f2d";
        private string x_trans_key = "6810h5";
        private float x_version = (float)2.0;
        private string x_type = "AUTH_CAPTURE";
        private char x_test_request = 'N';
        private int x_duplicate_window = 60;
        private char x_delim_char = '|'; //@
        private string x_response_format = "string"; //json
        private bool x_delim_data = true;
        private string x_method = "CC"; //json
        private string x_trans_id = "";
        private string x_auth_code = "CC"; //json

        private string x_secret_key = "4lph0ns3";

        private bool sandbox = true;
        /*********************************
         * End of Merchant configuration *
         *********************************/

        /*****************************************************
         * ---- PLEASE DON'T CHANGE ANYTHING BELOW HERE ---- *
         *****************************************************/
        string post_url;

        const string formatter = "{0,10}{1,16}";

        public void construct()
        {
            post_url = "https://api.astropaycard.com/verif/";
            if (this.sandbox)
            {
                post_url = "https://sandbox-api.astropaycard.com/verif/";
            }
        }

        public string validator(string card, int code, string expDate, float amount, string uniqueId, string invoice)
        {
            Hashtable post_values = new Hashtable();

            post_values.Add("x_login", this.x_login);
            post_values.Add("x_tran_key", this.x_trans_key);
            post_values.Add("x_version", this.x_version);
            post_values.Add("x_type", this.x_type);
            post_values.Add("x_test_request", this.x_test_request + "");
            post_values.Add("x_card_num", card);
            post_values.Add("x_card_code", code + "");
            post_values.Add("x_exp_date", expDate);
            post_values.Add("x_amount", amount + "");
            post_values.Add("x_unique_id", uniqueId);
            post_values.Add("x_invoice_num", invoice);
            post_values.Add("x_duplicate_window", this.x_duplicate_window + "");
            post_values.Add("x_delim_char", this.x_delim_char + "");
            post_values.Add("x_response_format", this.x_response_format);
            post_values.Add("x_delim_data", this.x_delim_data);
            post_values.Add("x_method", this.x_method);
            post_values.Add("x_trans_id", this.x_trans_id);
            post_values.Add("x_auth_code", this.x_auth_code);

            string response = this.curl(this.post_url + "validator", post_values);
            return response;
        }

        public string transtatus(string invoice)
        {
            Hashtable post_values = new Hashtable();

            post_values.Add("x_login", this.x_login);
            post_values.Add("x_trans_key", this.x_trans_key);
            post_values.Add("x_invoice_num", invoice);
            post_values.Add("x_test_request", this.x_test_request + "");
            post_values.Add("x_type", this.x_type);
            post_values.Add("x_delim_char", this.x_delim_char + "");

            string response = this.curl(this.post_url + "transtatus", post_values);
            return response;
        }

        /**
         * END OF PUBLIC INTERFACE
        */

        private string curl(string url, Hashtable post_values)
        {
            String post_string = "";
            String post_response = "";
            HttpWebRequest objRequest;
            foreach (DictionaryEntry field in post_values)
            {
                post_string += field.Key + "=" + field.Value + "&";
            }
            post_string = post_string.TrimEnd('&');

            try
            {
                // create an HttpWebRequest object to communicate with AstroPay transaction server
                objRequest = (HttpWebRequest)WebRequest.Create(url);
                objRequest.Method = "POST";
                objRequest.ContentLength = post_string.Length;
                objRequest.ContentType = "application/x-www-form-urlencoded, charset=utf-8";

                // post data is sent as a stream
                StreamWriter myWriter = null;
                myWriter = new StreamWriter(objRequest.GetRequestStream());
                myWriter.Write(post_string);
                myWriter.Close();

                // returned values are returned as a stream, then read into a string
                HttpWebResponse objResponse = (HttpWebResponse)objRequest.GetResponse();
                using (StreamReader responseStream = new StreamReader(objResponse.GetResponseStream()))
                {
                    post_response = responseStream.ReadToEnd();
                    responseStream.Close();
                }

                // the response string is broken into an array
                // The split character specified here must match the delimiting character specified above
            }
            catch (Exception e)
            {
                throw new Exception("Error ocurred in HttpWebRequest");
            }
            return post_response;
        }

        public string getSign(string key, string message)
        {
            System.Security.Cryptography.HMAC hmac = System.Security.Cryptography.HMAC.Create("HMACSHA256");
            hmac.Key = System.Text.Encoding.UTF8.GetBytes(key);
            byte[] hash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(message));
            return BitConverter.ToString(hash).Replace("-", "").ToUpperInvariant();
        }

        public bool md5Validator(string md5Hash, string transactionId, string amount)
        {
            MD5 md5 = MD5.Create();
            String input = this.x_login + transactionId + amount;
            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
            byte[] hash = md5.ComputeHash(inputBytes);

            // step 2, convert byte array to hex string
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < hash.Length; i++)
            {
                sb.Append(hash[i].ToString("X2"));
            }
            string nuevoMd5 = sb.ToString();
            return nuevoMd5.Equals(md5Hash.ToUpper());
        }
    }
}
