﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APCPrueba
{
    public class Program
    {
        static void Main(string[] args)
        {
            AstroPayCard astro = new AstroPayCard();
            astro.construct();
            string response = astro.validator("1175000000000100", 1234, "05/2015", (float)7, "id user", "InvoicePrueba1102");
            char[] chars = {'|'};
            //Must validate response
            string[] responseArray = response.Split(chars);
            bool validateMd5 = astro.md5Validator(responseArray[39], responseArray[6], "7");
            Console.WriteLine(response);
            string responseStatus = astro.transtatus("InvoicePrueba1102");
            Console.WriteLine(responseStatus);
        }
    }
}
