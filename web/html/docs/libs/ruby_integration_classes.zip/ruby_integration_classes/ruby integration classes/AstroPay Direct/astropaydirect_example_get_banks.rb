require_relative 'astropaydirect'

#data to send
country = 'BR'


#create the AstroPayDirect object
astropay_direct = AstroPayDirect.new

#get the banks of that country
response = astropay_direct.get_banks_by_country(country)
response = JSON.parse(response.body)
=begin
  The response is a json (by default) with the following data:
  [{"code":"TE","name":"TEST BANK (GNB)","logo":"https:\/\/sandbox.astropaycard.com\/images\/astropay-testing-logo.jpg"}]
=end

bank = response[0]['code'] #bank = 'TE'

