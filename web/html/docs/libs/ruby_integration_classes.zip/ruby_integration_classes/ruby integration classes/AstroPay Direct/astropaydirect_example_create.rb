require_relative 'astropaydirect'

#data to send
invoice = 'inv12'
amount = 2 #now in U$D
iduser = '1232412'
bank = 'TE'
country = 'BR'
currency = 'BRL'
description = 'desc'
cpf = 123021392
sub_code = 1
return_url = 'http://yourdomain.com/return_ulr'
confirmation_url = 'http://yourdomain.com/confirmation_url'

#create the AstroPayDirect object
astropay_direct = AstroPayDirect.new

#create the transaction
response = astropay_direct.create(invoice, amount, iduser, bank, country, currency, description, cpf, sub_code, return_url, confirmation_url)
response = JSON.parse(response.body)
=begin
  The response is a json (by default) with the following data:
  {"status"=>"OK", "link"=>"https://sandbox.astropaycard.com/pay_with_apd?id=ZojmkLsAZLTd7tWu5mZWZxIgqFw9ZutW"}
=end

if(response['status'] == 'ok')
	#do something
	link_to_the_user = response['link'] #redirect the user to this link
end