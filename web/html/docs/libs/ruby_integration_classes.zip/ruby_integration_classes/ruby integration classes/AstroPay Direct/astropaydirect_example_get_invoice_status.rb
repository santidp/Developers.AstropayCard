require_relative 'astropaydirect'

#data to send
invoice = 'inv12'

#create the AstroPayDirect object
astropay_direct = AstroPayDirect.new


#get invoice status
response = astropay_direct.get_invoice_status(invoice)
response = JSON.parse(response.body)
=begin
  The response is a json (by default) with the following data:
  {"result"=>"6", "x_iduser"=>"0", "x_invoice"=>"inv2", "x_amount"=>0, "PT"=>0, "Sign"=>"8E5AEE67F15393E0181B4AF1B693CCD83B376A1DE297E92515A0A2BC33645CF4", "x_document"=>-1, "x_bank"=>" ", "x_payment_type"=>0, "x_bank_name"=>" ", "x_currency"=>" "}
=end

status = response['result'] #status

=begin
status  | description
---------------------
6       | Invalid invoice
7       | Pending transaction waiting approval
8       | Expired, rejected by the bank or cancelled by the user.
9       | Amount paid. Transaction successfully concluded
=end

