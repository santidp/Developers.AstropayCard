=begin
    Class of AstroPay Card
    
    @author Andres Zibula (andres.z@astropaycard.com)
    @version 1.0

=end

require 'openssl'
require 'net/http'
require 'uri'
require 'json'

class AstroPayDirect

  def initialize()
    @x_login = "xxxx"
    @x_trans_key = "xxxx"
  
    @x_login_for_webpaystatus = "xxxx"
    @x_trans_key_for_webpaystatus = "xxxx"
  
    @secret_key = "xxxx"

    @sandbox = true

    
    @astro_urls = Hash.new

    if (@sandbox)
      @astro_urls['create'] = 'http://sandbox.astropaycard.com/api_curl/apd/create'
      @astro_urls['status'] = 'http://sandbox.astropaycard.com/apd/webpaystatus'
      @astro_urls['exchange'] = 'http://sandbox.astropaycard.com/apd/webcurrencyexchange'
      @astro_urls['banks'] = 'http://sandbox.astropaycard.com/api_curl/apd/get_banks_by_country'
    else
      @astro_urls['create'] = 'https://astropaycard.com/api_curl/apd/create'
      @astro_urls['status'] = 'https://astropaycard.com/apd/webpaystatus'
      @astro_urls['exchange'] = 'https://astropaycard.com/apd/webcurrencyexchange'
      @astro_urls['banks'] = 'https://astropaycard.com/api_curl/apd/get_banks_by_country'
    end
  end



  def create(invoice, amount, iduser, bank, country, currency, description, cpf, sub_code, return_url, confirmation_url, response_type = 'json')
    
    params_hash = {
      #Mandatory
      'x_login' => @x_login,
      'x_trans_key' => @x_trans_key,
      'x_invoice' => invoice,
      'x_amount' => amount,
      'x_iduser' => iduser,
      
      #Optional
      'x_bank' => bank,
      'x_country' => country,
      'x_currency' => currency,
      'x_description' => description,
      'x_cpf' => cpf,
      'x_sub_code' => sub_code,
      'x_return' => return_url,
      'x_confirmation' => confirmation_url,
      'type' => response_type
    }
    
    message_to_control = "#{invoice}D#{amount}P#{iduser}A"
    
    sha256 = OpenSSL::Digest::SHA256.new
    control = OpenSSL::HMAC.hexdigest(sha256, [@secret_key].pack('A*'), [message_to_control].pack('A*'))
    control = control.upcase

    
    params_hash['control'] = control
    
    return astro_curl(@astro_urls['create'], params_hash)
  end

  def get_banks_by_country(country, type = 'json')
    params_hash = {
      #Mandatory
      'x_login' => @x_login,
      'x_trans_key' => @x_trans_key,
      'country_code' => country,
      'type' => type
    }
    
    return astro_curl(@astro_urls['banks'], params_hash)
  end

  def get_invoice_status(invoice, type = 'json')
    params_hash = {
      #Mandatory
      'x_login' => @x_login_for_webpaystatus,
      'x_trans_key' => @x_trans_key_for_webpaystatus,
      'x_invoice' => invoice,
      'x_response_format' => type
    }
    
    return astro_curl(@astro_urls['status'], params_hash)
  end
  
  def get_exchange(country = 'BR', amount = 1)
    params_hash = {
      #Mandatory
      'x_login' => @x_login_for_webpaystatus,
      'x_trans_key' => @x_trans_key_for_webpaystatus,
      'x_country' => country,
      'x_amount' => amount
    }
    
    return astro_curl(@astro_urls['exchange'], params_hash)
  end

  def astro_curl(url, params_hash)
    uri = URI.parse(url)

    http = Net::HTTP.new(uri.host, uri.port)

    request = Net::HTTP::Post.new(uri.request_uri)
    request.set_form_data(params_hash)

    return http.request(request)
  end

end