require_relative 'astropaycard'

#create the AstroPayCard object
astropay_card = AstroPayCard.new

#test card
card_number = 1175000000000025
card_ccv = 1234
card_exp_date = "05/2015"

amount = 2

transaction_id = "xxxx" #you need to create the transaction to get this

#void a transaction
response = astropay_card.void_transaction(transaction_id, card_number, card_ccv, card_exp_date, amount)

#control hash
if(response['md5_hash'] != astropay_card.calculate_control(response['TransactionID'], response['x_amount']))
	puts("md5 hash not matching\n") #Duplicated transaction return empty hash, so it will never match
	exit
end

if(response['response_code'] == 1) #approved
	#ok
end