require_relative 'astropaycard'

#create the AstroPayCard object
astropay_card = AstroPayCard.new

#test card
card_number = 1175000000000025
card_ccv = 1234
card_exp_date = "05/2015"

amount = 2
merchant_user_id = "5asd2f34"
merchant_transaction_id = "23sd4f8s2352121"

approval_code = "xxxxx" #auth first to get this

#create capture transaction
response = astropay_card.capture_transaction(approval_code, card_number, card_ccv, card_exp_date, amount, merchant_user_id, merchant_transaction_id)

#control hash
if(response['md5_hash'] != astropay_card.calculate_control(response['TransactionID'], response['x_amount']))
	puts("md5 hash not matching\n") #Duplicated transaction return empty hash, so it will never match
	exit
end

if(response['response_code'] == 1) #approved
	#ok
	trans_id = response['TransactionID']
end