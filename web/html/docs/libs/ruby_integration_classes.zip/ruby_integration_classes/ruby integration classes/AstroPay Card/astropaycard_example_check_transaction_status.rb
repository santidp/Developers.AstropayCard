require_relative 'astropaycard'

#create the AstroPayCard object
astropay_card = AstroPayCard.new

transaction_id = "xxxx" #you need to create the transaction to get this

#check the status of a transaction
response = astropay_card.check_transaction_status(transaction_id)

if(response.has_key?("error") and response['error'] == "No transactions found")
	#no transaction with that id
elsif(response['response_code'] == 1) #approved
	#ok
end