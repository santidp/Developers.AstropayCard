=begin
    Class of AstroPay Card
    
    @author Andres Zibula (andres.z@astropaycard.com)
    @version 1.1

=end

require 'net/http'
require 'uri'
require 'json'
require 'digest/md5'

class AstroPayCard

  def initialize()
    @x_login = "xxxx"
    @x_trans_key = "xxxx"

    @sandbox = true

    @base_url = "https://api.astropaycard.com/"
    @sandbox_base_url = "https://sandbox-api.astropaycard.com/"
    
    @validator_url = "verif/validator"
    @transtatus_url = "verif/transtatus"

    @x_version = "2.0"            #AstroPay API version (default "2.0")
    @x_delim_char = "|"           #Field delimit character, the character that separates the fields (default "|")
    @x_test_request               #Change to N for production
    @x_duplicate_window = 30      #Time window of a transaction with the sames values is taken as duplicated (default 120)
    @x_method = "CC"
    @x_response_format = "json"   #Response format: "string", "json", "xml" (default: string) (recommended: json)
    
    @astro_urls = Hash.new

    if (@sandbox)
      @validator_url = "#{@sandbox_base_url}#{@validator_url}"
      @transtatus_url = "#{@sandbox_base_url}#{@transtatus_url}"
      @x_test_request = "N"
    else
      @validator_url = "#{@base_url}#{@validator_url}"
      @transtatus_url = "#{@base_url}#{@transtatus_url}"
      @x_test_request = "N"
    end
  end

  
=begin
  authorizes a transaction

  x_card_num AstroPay Card number (16 digits)
  x_card_code AstroPay Card security code (CVV)
  x_exp_date AstroPay Card expiration date
  x_amount Amount of the transaction
  x_unique_id Unique user ID of the merchant
  x_invoice_num Merchant transaction identificator, i.e. the order number
  additional_params Array of additional info that you would send to AstroPay for reference purpose.
  return json of params returned by AstroPay capture API. Please see section 3.1.3 "Response" of AstroPay Card integration manual for more info
=end
  def auth_transaction(x_card_num, x_card_code, x_exp_date, x_amount, x_unique_id, x_invoice_num, additional_params = nil)
    data = Hash.new

    data['x_login'] = @x_login
    data['x_tran_key'] = @x_trans_key
    data['x_card_num'] = x_card_num
    data['x_card_code'] = x_card_code
    data['x_exp_date'] = x_exp_date
    data['x_amount'] = x_amount
    data['x_unique_id'] = x_unique_id
    data['x_version'] = @x_version
    data['x_test_request'] = @x_test_request
    data['x_duplicate_window'] = @x_duplicate_window
    data['x_method'] = @x_method
    data['x_invoice_num'] = x_invoice_num
    data['x_delim_char'] = @x_delim_char
    data['x_response_format'] = @x_response_format
    data['x_type'] = "AUTH_ONLY"

    #Optional: Additional params
    unless (additional_params.nil?)
        additional_params.each do |key, value|
            data.store(key, value)
        end
    end

    return astro_curl(@validator_url, data)
  end

=begin
    Caputures previous authorized transaction

    x_auth_code The x_auth_code returned by auth_transaction method
    x_card_num AstroPay Card number (16 digits)
    x_card_code AstroPay Card security code (CVV)
    x_exp_date AstroPay Card expiration date
    x_amount Amount of the transaction
    x_unique_id Unique user ID of the merchant
    x_invoice_num Merchant transaction identificator, i.e. the order number
    additional_params Array of additional info that you would send to AstroPay for reference purpose.
    return json returned by AstroPay capture API. Please see section 3.1.3 "Response" of AstroPay Card integration manual for more info
=end
  def capture_transaction(approval_code, x_card_num, x_card_code, x_exp_date, x_amount, x_unique_id, x_invoice_num, additional_params = nil)
    data = Hash.new

    data['x_login'] = @x_login
    data['x_tran_key'] = @x_trans_key
    data['x_card_num'] = x_card_num
    data['x_card_code'] = x_card_code
    data['x_exp_date'] = x_exp_date
    data['x_amount'] = x_amount
    data['x_unique_id'] = x_unique_id
    data['x_version'] = @x_version
    data['x_test_request'] = @x_test_request
    data['x_duplicate_window'] = @x_duplicate_window
    data['x_method'] = @x_method
    data['x_invoice_num'] = x_invoice_num
    data['x_delim_char'] = @x_delim_char
    data['x_response_format'] = @x_response_format
    data['x_auth_code'] = approval_code
    data['x_type'] = "CAPTURE_ONLY"

    #Optional: Additional params
    unless (additional_params.nil?)
        additional_params.each do |key, value|
            data.store(key, value)
        end
    end

    return astro_curl(@validator_url, data)
  end

=begin
    Authorize and capture a transaction at the same time (if it is possible)

    x_card_num AstroPay Card number (16 digits)
    x_card_code AstroPay Card security code (CVV)
    x_exp_date AstroPay Card expiration date
    x_amount Amount of the transaction
    x_unique_id Unique user ID of the merchant
    x_invoice_num Merchant transaction identificator, i.e. the order number
    additional_params Array of additional info that you would send to AstroPay for reference purpose.
    return json returned by AstroPay capture API. Please see section 3.1.3 "Response" of AstroPay Card integration manual for more info
=end     
  def auth_capture_transaction(x_card_num, x_card_code, x_exp_date, x_amount, x_unique_id, x_invoice_num, additional_params = nil)
    data = Hash.new

    data['x_login'] = @x_login
    data['x_tran_key'] = @x_trans_key
    data['x_card_num'] = x_card_num
    data['x_card_code'] = x_card_code
    data['x_exp_date'] = x_exp_date
    data['x_amount'] = x_amount
    data['x_unique_id'] = x_unique_id
    data['x_version'] = @x_version
    data['x_test_request'] = @x_test_request
    data['x_duplicate_window'] = @x_duplicate_window
    data['x_method'] = @x_method
    data['x_invoice_num'] = x_invoice_num
    data['x_delim_char'] = @x_delim_char
    data['x_response_format'] = @x_response_format
    data['x_type'] = "AUTH_CAPTURE"

    #Optional: Additional params
    unless (additional_params.nil?)
        additional_params.each do |key, value|
            data.store(key, value)
        end
    end

    return astro_curl(@validator_url, data)
  end

=begin    
    Refund a transaction

    transaction_id merchant invoice number sent in previus call of capture_transaction or auth_transaction
    x_card_num AstroPay Card number (16 digits)
    x_card_code AstroPay Card security code (CVV)
    x_exp_date AstroPay Card expiration date
    x_amount Amount of the transaction
    additional_params Array of additional info that you would send to AstroPay for reference purpose.
    return json returned by AstroPay capture API. Please see section 3.2.2 "Response" of AstroPay Card integration manual for more info
=end     
  def refund_transaction(transaction_id, x_card_num, x_card_code, x_exp_date, x_amount, additional_params = nil)
    data = Hash.new

    data['x_login'] = @x_login
    data['x_tran_key'] = @x_trans_key
    data['x_card_num'] = x_card_num
    data['x_card_code'] = x_card_code
    data['x_exp_date'] = x_exp_date
    data['x_amount'] = x_amount
    data['x_version'] = @x_version
    data['x_test_request'] = @x_test_request
    data['x_duplicate_window'] = @x_duplicate_window
    data['x_method'] = @x_method
    data['x_trans_id'] = transaction_id
    data['x_delim_char'] = @x_delim_char
    data['x_response_format'] = @x_response_format
    data['x_type'] = "REFUND"
    
    #Optional: Additional params
    unless (additional_params.nil?)
        additional_params.each do |key, value|
            data.store(key, value)
        end
    end

    return astro_curl(@validator_url, data)
  end

=begin    
    VOID a transaction

    transaction_id merchant invoice number sent in previus call of capture_transaction or auth_transaction
    x_card_num AstroPay Card number (16 digits)
    x_card_code AstroPay Card security code (CVV)
    x_exp_date AstroPay Card expiration date
    x_amount Amount of the transaction
    additional_params Array of additional info that you would send to AstroPay for reference purpose.
    return json returned by AstroPay capture API. Please see section 3.2.2 "Response" of AstroPay Card integration manual for more info
=end     
  def void_transaction(transaction_id, x_card_num, x_card_code, x_exp_date, x_amount, additional_params = nil)
    data = Hash.new

    data['x_login'] = @x_login
    data['x_tran_key'] = @x_trans_key
    data['x_card_num'] = x_card_num
    data['x_card_code'] = x_card_code
    data['x_exp_date'] = x_exp_date
    data['x_amount'] = x_amount
    data['x_version'] = @x_version
    data['x_test_request'] = @x_test_request
    data['x_duplicate_window'] = @x_duplicate_window
    data['x_method'] = @x_method
    data['x_trans_id'] = transaction_id
    data['x_delim_char'] = @x_delim_char
    data['x_response_format'] = @x_response_format
    data['x_type'] = "VOID"
    
    #Optional: Additional params
    unless (additional_params.nil?)
        additional_params.each do |key, value|
            data.store(key, value)
        end
    end

    return astro_curl(@validator_url, data)
  end

=begin    
    Checks the status of a transaction

    x_invoice_num The merchant id sent in the transaction
    type 0 for basic info, 1 for detailed info
    return json. Please see section 3.2.3 of APC integration manual from more details.
=end     
  def check_transaction_status(x_invoice_num, type = 0) 
    data = Hash.new

    data['x_login'] = @x_login
    data['x_trans_key'] = @x_trans_key
    data['x_invoice_num'] = x_invoice_num
    data['x_delim_char'] = @x_delim_char
    data['x_test_request'] = @x_test_request
    data['x_response_format'] = @x_response_format
    data['x_type'] = type

    return astro_curl(@transtatus_url, data)
  end

  def astro_curl(url, params_hash)
    uri = URI.parse(url)

    http = Net::HTTP.new(uri.host, uri.port)

    request = Net::HTTP::Post.new(uri.request_uri)
    request.set_form_data(params_hash)

    response = http.request(request)

    return JSON.parse(response.body)
  end

  def calculate_control(transaction_id, amount)
    return Digest::MD5.hexdigest("#{@x_login}#{transaction_id}#{amount}");
  end

end
